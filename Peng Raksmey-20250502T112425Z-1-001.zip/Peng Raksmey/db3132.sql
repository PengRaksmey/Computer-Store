-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 18, 2024 at 08:29 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db3132`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcatagory`
--

DROP TABLE IF EXISTS `tblcatagory`;
CREATE TABLE IF NOT EXISTS `tblcatagory` (
  `CaTId` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `Catagory` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`CaTId`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tblcatagory`
--

INSERT INTO `tblcatagory` (`CaTId`, `Catagory`) VALUES
(1, 'Laptop'),
(2, 'Desktop'),
(3, 'PC Hardware'),
(4, 'Accessories');

-- --------------------------------------------------------

--
-- Table structure for table `tbldata`
--

DROP TABLE IF EXISTS `tbldata`;
CREATE TABLE IF NOT EXISTS `tbldata` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `ProName` varchar(250) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `CatId` int NOT NULL,
  `Description` varchar(5000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `imgUrl` varchar(250) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `desUrl` varchar(250) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `DateIn` datetime NOT NULL,
  `DateModified` datetime DEFAULT NULL,
  `Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbldata`
--

INSERT INTO `tbldata` (`id`, `ProName`, `CatId`, `Description`, `imgUrl`, `desUrl`, `DateIn`, `DateModified`, `Status`) VALUES
(252, 'Logitech BRIO 4K Webcam', 4, 'Multiple resolutions: 4K/30fps (up to 4096 x 2160 pixels)\r\n\r\n- Focus type: Autofocus\r\n\r\n- Lens type: Glass\r\n\r\n- Built-in mic: stereo, dual omni-directional\r\n\r\n- Diagonal field of view (dFoV): 90°/78°/65°\r\n\r\n- Digital zoom: 5x\r\n\r\n- USB connectivity\r\n\r\n- Cable length: 2.2 m\r\n\r\n- Dimensions (ATTACHABLE MOUNTING CLIP): Height: 19 mm, Width: 36 mm, Depth: 63 mm\r\n\r\n- Weight: 44g', 'Qur/image/Logitech.jpg', 'http://lsccomputer.com/index.php?route=product/product&path=227&product_id=7682', '2024-12-04 15:27:08', NULL, 1),
(251, ' My Passport Ultra 2TB My Passport Ultra 2TB', 3, 'Product Description\r\n- Connection Interface: 1 x USB 3.2 / USB 3.1 Gen 1 (USB Type-C)\r\n\r\n\r\n- Pre-Format: NTFS\r\n\r\n\r\n- Encryption: 256-Bit AES\r\n\r\n\r\n- Dimensions (L x W x H): 4.3 x 3.2 x 0.5\" / 109.2 x 81.3 x 12.7 mm\r\n\r\n\r\n- Weight: 140g\r\n\r\n\r\n- Color: Silver, Gold\r\n\r\n', 'Qur/image/Wd ultra 2tb.jpg', 'http://lsccomputer.com/index.php?route=product/product&product_id=4863', '2024-12-04 15:21:52', '2024-12-11 15:34:22', 1),
(250, 'iMac', 2, ' CPU: Apple M3 chip 8-Core CPU,8-core GPU, and 16-core Neural Engine\r\n\r\n-RAM: 16GB Unified\r\n\r\n-Storage: 512GB SSD\r\n\r\n-Display: 24\" ( 4480 x 2520 )  Retina\r\n\r\n-Wi-Fi + Bluetooth\r\n\r\n-Magic Keyboard  / Mouse / with Touch ID \r\n\r\n-Weight: 4.48Kg\r\n\r\n-Operating System: macOS\r\n\r\n-Color: Green, Yellow, Orange, Pink, Purple, Blue, Silver\r\n\r\nWarranty\r\n- 1-year hardware  \r\n- (No warranty for screen, battery, keyboard, fan & speaker, adapter) \r\n                            ', 'Qur/image/1150390223_Imac-M3-Blue-330x409.jpg', 'https://www.goldonecomputer.com/index.php?route=product/product&product_id=3905', '2024-12-04 15:14:46', '2024-12-11 11:50:54', 1),
(248, 'Dell Inspiron AIO DT 5420 Touch', 2, '- Intel® Core i5-1335U 10-Core (up to 4.6GHz, 12MB)\r\n\r\n- RAM 16GB DDR4\r\n\r\n- SSD 512GB PCIe\r\n\r\n- Optical Drive: Non\r\n\r\n- VGA intel Iris Xe Graphics\r\n\r\n- Camera: 1080p at 30 fps, FHD RGB camera\r\n\r\n- Wi-Fi 6E, LAN, Bluetooth\r\n\r\n- Built-in Speaker\r\n\r\n- Screen 23.8\" FHD Touch\r\n\r\n- Windows 11 License\r\n\r\n- Microsoft Office 2021 Home and Student License\r\n\r\n- Wireless Dell Keyboard\r\n\r\n- Wireless Dell Mouse\r\n\r\n- Mouse Pad', 'Qur/image/1761954876_Dell Inspiron AIO DT 5420 Touch.png', 'http://lsccomputer.com/index.php?route=product/product&path=221&product_id=8106', '2024-12-04 15:06:23', NULL, 1),
(249, 'SAMSUNG 990 Pro 2TB PCIe 4.0 NVMe M.2 SSD', 3, '- Interface: PCIe Gen 4.0 x4, NVMe 2.0\r\n\r\n- Form Factor: M.2 (2280)\r\n\r\n- Dimension (WxHxD): 80 x 22 x 2.3 mm\r\n\r\n- Write Speed: Up to 6,900 MB/s\r\n\r\n- Read Speed: Up to 7,450 MB/s\r\n\r\n- Weight: 9g', 'Qur/image/1412819495_SAMSUNG 990 Pro 2TB PCIe 4.0 NVMe M.2 SSD.jpg', 'http://lsccomputer.com/index.php?route=product/product&path=232&product_id=8352', '2024-12-04 15:10:21', NULL, 1),
(247, 'NB Dell Inspiron 3520 Silver', 1, '-CPU / Processor : 12th Gen Intel® Core™ i5-1235U (1.30 GHz up to 4.40 GHz Turbo, 12MB cache, 10cores, 12threads)\r\n-Operating System : DOS (No operating system)\r\n-RAM / Memory : 8 GB DDR4 (1x8GB) (3200AA)(2slots)\r\n-Storage : 512GB M.2 PCIe NVMe Solid State Drive (Free One slot support 2.5\'\')\r\n-Graphic : Intel® UHD Graphics\r\n-Display : 15.6\" FHD (1920 x 1080), 120Hz, WVA, Non-Touch, Anti-Glare, 250 nit, Narrow Border, LED-Backlit\r\n-Optical Drive : None\r\n-Wireless : Intel(R) Wi-Fi 6 AX201, 2x2, 8 02.11ax, Bluetooth(R) wireless card\r\n-Speaker : Stereo speakers, 2 W x 2 = 4 W total\r\n-LAN Ethernet Network : None\r\n-Webcam : 720p at 30 fps HD camera Single integrated microphone\r\n-Ports : 2x USB 3.2 Gen 1 Type-A ports, 1x USB 2.0 port, 1x Power Jack, 1x Headset (headphone and microphone combo) port, 1x SD-card slot, 1x HDMI 1.4 (Maximum resolution supported over HDMI is 1920x1080 @60Hz. No 4K/2K output)\r\n-Keyboard : English International Non-Backlit Keyboard\r\n-Battery : 3 Cell, 41 Wh, integrated\r\n-Weight: 1.65 kg (3.65 lbs.)\r\n-Warranty: 1Year on part and services (Warranty 6months on battery, No Warranty on adapter)', 'Qur/image/203769032_NB Dell Inspiron 3520 Silver.png', 'https://ptc-computer.com.kh/product/dell-inspiron-3520-black-core-i5-1235u-8gb-512gb-ssd-uhd-156-fhd--wi-fi-6--bt-ubuntu-1y-hpy0n', '2024-12-04 14:58:02', NULL, 1),
(245, 'Headset Logitech H390 USB', 4, 'Dimensions\r\n-Height: 171 mm\r\n-Width: 151 mm\r\n-Depth: 68 mm\r\n-Weight: 0.197 kg\r\n-Cable length: 1.9 m\r\nTechnical Specifications\r\n-Microphone Type: Bi-directional\r\n-Input Impedance: 32 Ohm\r\n-Sensitivity (headphone): 94 dBV/Pa +/- 3 dB\r\n-Sensitivity (microphone): -17 dBV/Pa +/- 4 dB\r\n-Frequency response (Headset): 20 Hz - 20 KHz\r\n-Frequency response (Microphone): 100 Hz - 10 KHz\r\n-Inbox: USB Computer Headset / User documentation\r\nSystem Requirement: Windows®, macOS, or ChromeOS™ and popular calling platforms. USB port\r\nWarranty Information 2-Year Limited Hardware Warranty', 'Qur/image/47653569_Headset Logitech H390 USB.png', 'https://ptc-computer.com.kh/product/headset-logitech-h390-usb-with-noise-canceling-mic-graphite-981-000485-2-years-warranty-rhwva', '2024-12-04 14:08:37', NULL, 1),
(242, 'CPU AMD 7Gen', 3, 'Name\r\nAMD Ryzen™ 7 7700X\r\nFamily\r\nRyzen\r\nSeries\r\nRyzen 7000 Series\r\nForm Factor\r\nDesktops , Boxed Processor\r\nMarket Segment\r\nEnthusiast Desktop\r\nAMD PRO Technologies\r\nNo\r\nConsumer Use\r\nYes\r\nRegional Availability\r\nGlobal\r\nFormer Codename\r\nRaphael AM5\r\nArchitecture\r\nZen 4\r\n# of CPU Cores\r\n8\r\nMultithreading (SMT)\r\nYes\r\n# of Threads\r\n16\r\nMax. Boost Clock\r\nUp to 5.4 GHz\r\nBase Clock\r\n4.5 GHz\r\nL1 Cache\r\n512 KB\r\nL2 Cache\r\n8 MB\r\nL3 Cache\r\n32 MB\r\nDefault TDP\r\n105W\r\nProcessor Technology for CPU Cores\r\nTSMC 5nm FinFET\r\nProcessor Technology for I/O Die\r\nTSMC 6nm FinFET\r\nCPU Compute Die (CCD) Size\r\n71mm²\r\nI/O Die (IOD) Size\r\n122mm²\r\nPackage Die Count\r\n2\r\nUnlocked for Overclocking\r\nYes\r\nAMD EXPO™ Memory Overclocking Technology\r\nYes\r\nPrecision Boost Overdrive\r\nYes\r\nCurve Optimizer Voltage Offsets\r\nYes\r\nAMD Ryzen™ Master Support\r\nYes\r\nCPU Socket\r\nAM5\r\nSupporting Chipsets\r\nA620 , X670E , X670 , B650E , B650\r\nCPU Boost Technology\r\nPrecision Boost 2\r\nInstruction Set\r\nx86-64\r\nSupported Extensions\r\nAES , AMD-V , AVX , AVX2 , AVX512 , FMA3 , MMX-plus , SHA , SSE , SSE2 , SSE3 , SSE4.1 , SSE4.2 , SSE4A , SSSE3 , x86-64\r\nThermal Solution (PIB)\r\nNot Included\r\nRecommended Cooler\r\nPremium air cooler recommended for optimal performance\r\nMax. Operating Temperature (Tjmax)\r\n95°C\r\n*OS Support\r\nWindows 11 - 64-Bit Edition , Windows 10 - 64-Bit Edition , RHEL x86 64-Bit , Ubuntu x86 64-Bit', 'Qur/image/CPU AMD 7Gen.jpg', 'https://vtech-computer.com/index.php?route=product/product&language=en-gb&product_id=4241&path=234', '2024-12-04 09:45:32', NULL, 1),
(246, 'ASUS TUF Gaming F15 FX507ZC4', 1, '-CPU / Processor : 12th Gen Intel® Core™ i5-12500H Processor ( 2.50GHz up to 4.50GHz,18MB Cached, 12cores: 4 P-cores and 8 E-cores)\r\n-Operating System : Window 11Home Single Language (64Bit)\r\n-RAM / Memory : 8GB DDR4 3200MHz (8GBx1) (2slots Support up to 32GB)\r\n-Storage : 512B M.2 NVMe PCIe 3.0 SSD\r\n-Graphic : NVIDIA® GeForce RTX 3050 4GB GDDR6\r\n-Display : 15.6-inch, FHD (1920 x 1080) 16:9, Value IPS-level, Anti-glare display, sRGB:62.5%, Adobe: 47.34%, Refresh Rate:144Hz, Optimus\r\n-Optical Drive : None\r\n-Wireless : Wi-Fi 6(Dual band) 2*2 + Bluetooth 5.2\r\n-Network: 10/100/1000 Mbps\r\n-Sound : Dolby Atmos AI noise-canceling technology Hi-Res certification Built-in array microphone 2-speaker system\r\n-Webcam: 720P HD camera\r\n-Ports : 1x 3.5mm Combo Audio Jack, 1x HDMI 2.1 TMDS, 2x USB 3.2 Gen 1 Type-A, 1x USB 3.2 Gen 2 Type-C support DisplayPort™ / G-SYNC, 1x RJ45 LAN port, 1x Thunderbolt™ 4 support DisplayPort\r\n-Keyboard: Backlit Chiclet Keyboard 1-Zone RGB Touchpad\r\n-Battery: 56WHrs, 4S1P, 4-cell Li-ion\r\n-Weight: 2.20 Kg (4.85 lbs)\r\n-What\'s in box: TUF backpack + MOUSE P304 TUF GAMING M5 V2\r\n-Warranty: 2Years Warranty + 1st Year Local Perfect Warranty', 'Qur/image/724097855_ASUS TUF Gaming F15 FX507ZC4.png', 'https://ptc-computer.com.kh/product/asus-tuf-gaming-f15-fx507zc4-hn108w-grey-i5-12500h-8g-512g-156fhd-vips-144hz-rtx3050-4g-w11-bp-2y-4ozmn', '2024-12-04 14:16:28', NULL, 1),
(254, 'MacBook Air MGN63 M1', 1, '\r\nMacBook Air MGN63 M1\r\n$719.00\r\nBrand: APPLE\r\nAvailability:  In Stock\r\nViewed  2147483647 times\r\nProduct Description\r\n- CPU Apple M1 8-Core CPU, 7Core GPU and 16-Core Neural Engine\r\n\r\n- RAM 8GB Unified Memory\r\n\r\n- 256GB PCIe-Bassed onboard SSD    \r\n\r\n- Two Thunderbolt 4 (USB-C) port    \r\n\r\n- Built in 720p FaceTime HD Camera    \r\n\r\n- WiFi 6, Bluetooth 5.0    \r\n\r\n- Headphone Jack, Stereo Speaker    \r\n\r\n- Backlit Magic Keyboard    \r\n\r\n- Touch ID Sensor    \r\n\r\n- Screen 13.3\"LED With Retina Display True Tone IPS 2560 by 1600 Pixels    \r\n\r\n- Weight: 1.29Kg, Color: Space Gray \r\n\r\n- Preinstalled MacOS', 'Qur/image/1070978907_Macbook air .jpg', 'http://lsccomputer.com/index.php?route=product/product&product_id=5695', '2024-12-11 09:57:16', NULL, 1),
(241, 'DESKTOP', 2, '   FREE: KEYBOARD, MUOSE ,MUOSEPAD\r\nCPU : Intel Core  I5-1235U\r\nRam  : 8GB DDR3\r\nStorage: 256 GB PCIe NVMe\r\nScreen : 21.5\" Full HD 1920 x 1080p 75Hz Anti-Glare Screen\r\nOptical Drive : None\r\nVGA on board : Intel Graphics\r\nCamera :HD camera\r\nNetwork and Communication : Wi-Fi (802.11ax) (Dual band) 1*1\r\nI/O Ports : HDM ,1 x USB 2.0 ,2 x USB 3.2 Gen 1 ,1 x USB-C 3.2 Gen 2 ,1 x USB 3.2 Gen 1 x LAN (Gigabit Ethernet) - RJ-45 ,Audio line-out ,Audio line-in\r\nWeight : 4kg\r\nOS :DOS\r\n1 Years hardware ( Motherboard )\r\n1 Year for screen \r\n                             \r\n                             \r\n                            ', 'Qur/image/458399152Dell Desktop.jpg', 'https://vtech-computer.com/index.php?route=product/product&language=en-gb&product_id=3865&path=221', '2024-12-04 09:37:07', '2024-12-14 13:39:45', 1),
(255, 'HUAWEI Mobile WiFi 5 (E5586-822)', 4, 'Product Description\r\n- Wi-Fi Transmission Standard: 802.11ac\r\n\r\n- Wi-Fi supported Frequency: 2.4G\r\n\r\n- Includes a 2400mAh battery\r\n\r\n- Support 4 SIM cards: Cellcard, Smart, Metfone, Seatel\r\n\r\n- support: 16 Devices\r\n\r\n- Operating Time up to 6 hours\r\n\r\n- Speed up to 195mbps download and 103mbps upload\r\n\r\n- USB Type C connector\r\n\r\n- Support: Micro SIM card slot\r\n\r\n- Language: Chinese, English\r\n\r\n- Wireless speed: 300Mbps', 'Qur/image/79572282_HUAWEI Mobile WiFi 5.jpg', 'http://lsccomputer.com/index.php?route=product/product&path=227&product_id=8308', '2024-12-11 11:44:34', NULL, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
