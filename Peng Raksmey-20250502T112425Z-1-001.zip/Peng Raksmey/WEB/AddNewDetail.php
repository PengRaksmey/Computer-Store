<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize variables
    $path = null;
    $Status = 1;

    // Handle file upload
    if (isset($_FILES["fImg"]) && $_FILES["fImg"]["error"] === 0) {
        $img = basename($_FILES["fImg"]["name"]); // Secure file name
        $rand = rand();
        $imgU = $rand . '_' . $img;
        $targetDir = __DIR__ . "/Qur/image/";
        $path = $targetDir . $imgU;

        // Create the target directory if it doesn't exist
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        // Validate file type
        $allowedTypes = ['image/jpg', 'image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($_FILES['fImg']['type'], $allowedTypes)) {
            echo "Invalid file type. Only JPG, PNG, WEBP, and GIF files are allowed.<br>";
            $path = null;
        } elseif (move_uploaded_file($_FILES['fImg']['tmp_name'], $path)) {
            echo "Image uploaded successfully.<br>";
        } else {
            echo "Failed to upload the image.<br>";
            switch ($_FILES['fImg']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    echo "The uploaded file exceeds the upload_max_filesize directive in php.ini.<br>";
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    echo "The uploaded file exceeds the MAX_FILE_SIZE directive specified in the HTML form.<br>";
                    break;
                case UPLOAD_ERR_PARTIAL:
                    echo "The uploaded file was only partially uploaded.<br>";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    echo "No file was uploaded.<br>";
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    echo "Missing a temporary folder.<br>";
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    echo "Failed to write file to disk.<br>";
                    break;
                case UPLOAD_ERR_EXTENSION:
                    echo "A PHP extension stopped the file upload.<br>";
                    break;
                default:
                    echo "Unknown error occurred.<br>";
                    break;
            }
            $path = null; // Set path to null to avoid storing invalid references
        }
    } else {
        echo "No image uploaded.<br>";
        $path = null;
    }

    // Save other form data
    $indate = date('Y/m/d H:i:s'); // Fixed date format

    include('Qur/dbCon.php'); // Include the database connection

    // Prepare and sanitize user input
    $proName = mysqli_real_escape_string($dbCon, $_POST["txtProName"]);
    $catType = mysqli_real_escape_string($dbCon, $_POST["CatType"]);
    $description = mysqli_real_escape_string($dbCon, $_POST["des"]);
    $desLink = mysqli_real_escape_string($dbCon, $_POST["txtDesLink"]);

    // Use relative path for the image URL in the database
    $dbImgPath = $path ? "Qur/image/" . $imgU : null;

    // Build query with sanitized values
    $queryAdd = "INSERT INTO tbldata (ProName, CatId, Description, imgUrl, desUrl, DateIn, status) 
                VALUES ('$proName', '$catType', '$description', '$dbImgPath', '$desLink', '$indate', '$Status')";

    // Execute query and handle results
    if (mysqli_query($dbCon, $queryAdd)) {
        echo '<h1>The Post Summary</h1>';
        echo 'New record created successfully!<br>';

        // Retrieve and display the latest post
        $qTop = "SELECT * FROM tbldata ORDER BY DateIn DESC LIMIT 1";
        $rTop = $dbCon->query($qTop);

        if ($rTop->num_rows > 0) {
            while ($row = $rTop->fetch_assoc()) {
                echo '<br> Posted ID: ' . $row["id"];
                echo '<br> Posted Name: ' . $row["ProName"];
                echo '<br> Posted Category: ' . $row["CatId"];
                echo '<br> Posted Description: ' . $row["Description"];
                echo '<br> Posted URL: ' . $row["desUrl"];
                if ($row["imgUrl"]) {
                    echo '<br> Posted Image:<br> <img src="' . $row["imgUrl"] . '" style="max-width: 500px;"/><br>';
                }
                echo '<br> Status: Active';
            }
        } else {
            echo "No results found.";
        }
    } else {
        echo "Error: " . $queryAdd . "<br>" . mysqli_error($dbCon);
    }
    $dbCon->close();
} else {
    echo "Invalid request method.";
}
?>
