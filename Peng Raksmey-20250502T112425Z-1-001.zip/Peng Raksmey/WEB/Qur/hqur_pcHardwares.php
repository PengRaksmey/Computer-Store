<?php
  include ('dbCon.php');
  $qw = 'SELECT * FROM tbldata where CatId=3 Order By DateIn DESC Limit 3';
  $rw = $dbCon->query($qw);

  if ($rw->num_rows > 0)
  // output data of each row
  {
    echo '<table width="1280px" cellpadding="5px" cellspacing="5px">';
      echo '<tr>';
      while($row = $rw->fetch_assoc())
    {    
        echo '<td width="380px" style="vertical-align: top; text-align: center">';
        echo '<img src="'. $row["imgUrl"] .'" width="350px" height="280px" />';
        echo '<h3>'. $row["ProName"] . '</h3></td>';
    }
       echo '</tr>';
    echo '</table>';
  }
  else 
      echo '0 results';
  $dbCon->close(); 
?>