<?php
include('dbCon.php');

// Ensure all required POST variables exist
if (isset($_POST["txtId"], $_POST["txtProName"], $_POST["CatType"], $_POST["des"], $_POST["txtDesLink"], $_POST["StatDrp"])) {
    $sfId = $_POST["txtId"];
    $ProName = $_POST["txtProName"];
    $CatType = $_POST["CatType"];
    $Description = $_POST["des"];
    $desUrl = $_POST["txtDesLink"];
    $Status = $_POST["StatDrp"];
    $ModifiedDate = date('Y/m/d H:i:s');

    // Use prepared statement to update the database
    $queryUpdate = "UPDATE tbldata SET 
        ProName = ?, 
        CatId = ?, 
        Description = ?, 
        desUrl = ?, 
        DateModified = ?, 
        Status = ? 
        WHERE id = ?";

    $stmt = $dbCon->prepare($queryUpdate);
    if ($stmt) {
        // Bind parameters
        $stmt->bind_param(
            "ssssssi", 
            $ProName, 
            $CatType, 
            $Description, 
            $desUrl, 
            $ModifiedDate, 
            $Status, 
            $sfId
        );

        // Execute the query
        if ($stmt->execute()) {
            $stmt->close();
            $dbCon->close();
            header("Location: ../EditPro.php");
            exit();
        } else {
            echo "Error executing query: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error preparing query: " . $dbCon->error;
    }

    $dbCon->close();
} else {
    echo "Missing required POST data.";
}
?>
