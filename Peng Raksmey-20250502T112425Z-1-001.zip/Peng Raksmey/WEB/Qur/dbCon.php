<?php
    $dbCon = mysqli_connect('localhost', 'root', '', 'db3132') or die ('Not Connected');
?>