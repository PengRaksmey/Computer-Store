<img src="Qur/image/Dell Desktop.jpg" width="100%"/> 
<img src="Qur/image/ASUS TUF.png" width="100%"/> 
<img src="Qur/image/ASUS TUF Gaming F15 FX507ZC4.png" width="100%"/> 
<img src="Qur/image/DESKTOP ACER AIO.png" width="100%"/> 
<img src="Qur/image/MacBook Pro 16.jpg" width="100%"/> 
<img src="Qur/image/SAMSUNG 990 Pro.jpg" width="100%"/> 


