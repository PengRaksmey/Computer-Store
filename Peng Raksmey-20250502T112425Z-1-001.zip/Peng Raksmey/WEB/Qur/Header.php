<img src="Qur/image/Logos2.jpg" alt="Centered Image" style="display: block; margin: auto;width:100%"   />
<br>
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="home.php">Home</a>
&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
<a href="laptop.php">Laptop</a>
&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
<a href="desktops.php">Desktop</a>
&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
<a href="pc_hardware.php">PC Hardware</a>
&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
<a href="accessories.php">Accessories</a>