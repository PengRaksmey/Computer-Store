<?php
    include ('dbCon.php');
    $qw = 'SELECT * FROM tblcatagory';
    $rtt = $dbCon->query($qw);
?>