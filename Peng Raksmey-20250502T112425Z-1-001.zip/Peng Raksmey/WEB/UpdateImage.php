

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
    <?php
        include('Qur/dbCon.php');
        $sfId = $_GET["fdId"];
        $qwAll = 'SELECT * FROM tbldata WHERE id='.$sfId;
        $rwAll = $dbCon->query($qwAll);
        $row = $rwAll->fetch_assoc();
    ?>
</head>

<body>
<center>
    <table style="width:1280px">
        <tr>
            <td colspan="2">
                <?php include('Qur/Header.php'); ?>
            </td>
        </tr>
        <tr>
            <td style="width:920px; vertical-align: top">
               <form name="frmUpdate" action="Qur/qurUpdateImage.php" method="post" enctype="multipart/form-data">
                <table style="width:920px; font-size:20pt">
                    <tr>
                        <td style="width:920px;padding: 5px">
                            <h3> Updating New Image </h3>
                        </td>
                    </tr>                    
                    <tr>
                        <td style="width:920px;padding: 5px"><input type="text" name="txtId" hidden="true"  style="width:650px;  font-size:20pt" value=<?php echo $row["id"]; ?> ></td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">
                            <font size="+2">
                          <?php echo $row["ProName"]; ?> 
                            </font></td>
                    </tr>
                    <tr>
                        <td style="padding: 5px; text-align: center">
                            <img name="imgCur" src="<?php echo $row["imgUrl"]; ?>"  style="width: 500px;" /> 
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px"><input type="file" name="imgUpdate" style="width:650px; font-size:20pt"></td>
                    </tr>
                    
                    
                    <tr>
                        <td style="padding: 5px">
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="Submit" name="cmdSubmit" value="Submit" style="font-size:20pt">
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="Reset" name="cmdReset" value="Cancel" style="font-size:20pt"> 
                        </td>
                    </tr>
                </table>
                </form>
            </td>
            <td style="width:350px; vertical-align: top">
                <?php include('Qur/qur_RSide.php'); ?>
            </td>
        </tr>
        <tr style="background-color:bisque;">
            <td>CopyRight@2024, NUM-IT31</td>
            <td style="text-align: center">
                <a href="aboutus.html">Contact</a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="contactus.html">Contact</a>
            </td>
        </tr>
    </table>
</center>
</body>
</html>