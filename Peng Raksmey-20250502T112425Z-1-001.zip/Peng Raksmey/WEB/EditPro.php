<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<center>
    <table style="width:1280px">
        <tr>
            <td colspan="2">
               <?php include('Qur/header.php'); ?>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="width:1280px; vertical-align: top">
                <?php include('Qur/ListProAdminQur.php'); ?>
            </td>
        </tr>
        <tr style="background-color:bisque;">
            <td>CopyRight@2024, NUM-IT31</td>
            <td style="text-align: center">
                <a href="aboutus.html">About</a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="contactus_address.html">Contact</a>
            </td>
        </tr>
    </table>
</center>
</body>
</html>