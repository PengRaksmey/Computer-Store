<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Add New</title>
</head>
<body>
<center>
    <table style="width:1280px">
        <tr>
            <td colspan="2">
               <?php include('Qur/Header.php'); ?>
            </td>
        </tr>
        <tr>
            <td style="width:920px; vertical-align: top">
               <form name="frmAddNew" action="AddNewDetail.php" method="post" enctype="multipart/form-data">
                <table style="width:920px; font-size:20pt">
                    <tr>
                        <td colspan="2" style="padding: 5px">
                            <h2> Add New Information </h2>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:220px;padding: 5px">Product Name :</td>
                        <td style="width:700px;padding: 5px">
                            <input type="text" name="txtProName" style="width:650px; font-size:20pt" required>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Product Type :</td>
                        <td style="padding: 5px">
                        <?php
                            include('Qur/TourTypeQuery.php');
                            if ($rtt->num_rows > 0) {
                                echo '<select name="CatType" style="width: 150px">';
                                while ($roft = $rtt->fetch_assoc()) {
                                    echo '<option value="' . htmlspecialchars($roft["CaTId"]) . '">' . htmlspecialchars($roft["Catagory"]) . '</option>';
                                }
                                echo '</select>';
                            } else {
                                echo "No categories found.";
                            }
                        ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Description :</td>
                        <td style="padding: 5px">
                            <textarea rows="4" name="des" style="width:650px; font-size:20pt" required></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Destination Link :</td>
                        <td style="padding: 5px">
                            <input type="url" name="txtDesLink" style="width:650px; font-size:20pt">
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Choose Image :</td>
                        <td style="padding: 5px">
                            <input type="file" name="fImg" style="font-size:20pt" accept="image/*">
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px"></td>
                        <td style="padding: 5px">
                            <input type="submit" name="cmdSubmit" value="Submit" style="font-size:20pt">
                            <input type="reset" name="cmdReset" value="Cancel" style="font-size:20pt"> 
                        </td>
                    </tr>
                </table>
                </form>
            </td>
            <td style="width:350px; vertical-align: top">
                <?php include('Qur/qur_RSide.php'); ?>
            </td>
        </tr>
        <tr style="background-color:bisque;">
            <td>CopyRight@2024, NUM-IT31</td>
            <td style="text-align: center">
                <a href="aboutus.html">About</a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="contactus_address.html">Contact</a>
            </td>
        </tr>
    </table>
</center>
</body>
</html>
