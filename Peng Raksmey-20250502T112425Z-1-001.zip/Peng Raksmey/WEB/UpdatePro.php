
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
    <?php
        include('Qur/dbCon.php');
        $sfId = $_GET["fdId"];
        $qwAll = 'SELECT * FROM tbldata WHERE id='.$sfId;
        $rwAll = $dbCon->query($qwAll);
        $row = $rwAll->fetch_assoc();
    ?>
</head>

<body>
<center>
    <table style="width:1280px">
        <tr>
            <td colspan="2">
                <?php include('Qur/Header.php'); ?>
            </td>
        </tr>
        <tr>
            <td style="width:920px; vertical-align: top">
               <form name="frmUpdate" action="Qur/qurUpdatePro.php" method="post" enctype="multipart/form-data">
                <table style="width:920px; font-size:20pt">
                    <tr>
                        <td colspan="2" style="padding: 5px">
                            <h2> Updating New Information </h2>
                        </td>
                    </tr>                    
                    <tr>
                        <td style="width:220px;padding: 5px">
                        <td style="width:700px;padding: 5px"><input type="text" name="txtId" hidden="true"  style="width:650px;  font-size:20pt" value=<?php echo $row["id"]; ?> ></td>
                    </tr>
                    <tr>
                        <td style="width:220px;padding: 5px">Product Name :</td>
                        <td style="width:700px;padding: 5px"><input type="text" name="txtProName" value=<?php echo $row["ProName"]; ?> style="width:650px;  font-size:20pt"></td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Product Type :</td>
                        <td style="padding: 5px">
                          <?php
                            include('Qur/TourTypeQuery.php');
                            if ($rtt->num_rows > 0)
                            {
                                echo '<select name="CatType" style="width: 150px">';
                                while($roft = $rtt->fetch_assoc())
                                echo ('"<option value="'.$roft["CaTId"].'">'.$roft["Catagory"].'</option>"');
                                echo '</select>';
                            }
                            else 
                                echo "0 results";
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Description :</td>
                        <td style="padding: 5px"><textarea rows="4" name="des" style="width:650px;  font-size:20pt"> <?php echo $row["Description"]; ?> 
                            </textarea></td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Destination Link :</td>
                        <td style="padding: 5px"><input type="text" name="txtDesLink" value=<?php
                         echo $row["desUrl"]; ?> style="width:650px;  font-size:20pt"></td>
                    </tr>
                    <tr>
                        <td style="padding: 5px">Status :</td>
                        <td style="padding: 5px">
                            <?php 
                                if($row["Status"]==1)
                                {
                                    echo'<select name="StatDrp" style="width: 150px">';
                                    echo ('"<option value=1 selected>Active</option>"');
                                    echo ('"<option value=0>Inactive</option>"');
                                    echo '</select>';
                                }
                                else
                                {
                                    echo'<select name="StatDrp" style="width: 150px">';
                                    echo ('"<option value=1 >Active</option>"');
                                    echo ('"<option value=0 selected>Inactive</option>"');
                                    echo '</select>';
                                }
                            ?>

</select>
                        </td>
                    </tr>
     
                    <tr>
                        <td style="padding: 5px"></td>
                        <td style="padding: 5px">
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="Submit" name="cmdSubmit" value="Submit" style="font-size:20pt">
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="Reset" name="cmdReset" value="Cancel" style="font-size:20pt"> 
                        </td>
                    </tr>
                </table>
                </form>
            </td>

            <td style="width:350px; vertical-align: top">
                <?php include('Qur/qur_RSide.php'); ?>
            </td>
        </tr>
        <tr style="background-color:bisque;">
            <td>CopyRight@2024, NUM-IT31</td>
            <td style="text-align: center">
                <a href="aboutus.html">About</a>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="contactus_address.html">Contact</a>
            </td>
        </tr>
    </table>
</center>
</body>
</html>